.. This is a comment. Note how any initial comments are moved by
   transforms to after the document title, subtitle, and docinfo.

.. demo.rst from: http://docutils.sourceforge.net/docs/user/rst/demo.txt

.. |EXAMPLE| image:: static/yi_jing_01_chien.jpg
   :width: 1em

**********************
Home Page
**********************

.. contents:: Table of Contents

Web App
========

A simple Boostrap web application is installed to /var/www/html during the set up Wizard.

The web application contains links to the Login page, GeoServer, OpenLayers Demo, LeafletJS Demo, and Docs.

.. image:: _static/GeoHelm-Main.png

Troubleshooting
===============

If links on the home page do not function properly, check the index.html page to verify that links are pointing to your IP or hostname.




